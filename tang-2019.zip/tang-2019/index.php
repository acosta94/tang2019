<?php include('header.php') ?>

<div class="nav_home_cont d-none d-md-block">
    <div class="mas_nav_cont mas_nav_home_button">
        <div class="mas_nav">
            <div class="mas_nav_item horizontal"></div>
            <div class="mas_nav_item vertical"></div>
        </div>
    </div>
    <div class="colores_cont">
    </div>
</div>
<div class="fondo_madera">
    <div class="izquierdo">
        <a href="" class="sobre_home_a"><img src="" alt="Naranjada Mix" class="sobre sobre_home"></a>
    </div><!--
    --><div class="derecho">
        <div class="plasta_circular">
            <div class="receta_home_cont">
                <div class="receta_home">
                    <p class="receta_home_nombre"></p>
                    <a href="" class="receta_home_img_a"><img src="" alt="" class="receta_home_img"></a>
                </div>
            </div>
        </div>
        <div class="home_flecha_cont izquierda flecha_del_home">
            <div class="home_flecha"></div>
        </div>
        <div class="home_flecha_cont derecha flecha_del_home">
            <div class="home_flecha"></div>
        </div>
    </div>
</div>

    <div id="promopopup" class="popup panel panel-primary">
        <a href="https://www.contangquieromas.com/" target="_blank">
            <img src="<?=$site_url?>img/promo-popup.png">
        </a>
    </div>
<?php include('footer.php') ?>