    <div class="promo">
        <div class="cerrar_promo">
            <div class="mas_nav">
                <div class="mas_nav_item horizontal"></div>
                <div class="mas_nav_item vertical"></div>
            </div>
        </div>
        <img src="<?=$site_url?>img/promo.png" alt="Con Tang quiero más" class="promo_img">
    </div>
    
    
    <script src="https://unpkg.com/shufflejs@5"></script>
    <script src="<?=$site_url?>js/jquery-3.3.1.min.js"></script>
    <script src="<?=$site_url?>js/tang.js"></script>
    <script src="<?=$site_url?>js/bootstrap.min.js"></script>
</body>
</html>